#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#define mutation_rate 240

int main() {
	int i, j, m, n; //m,nΪ���꣬iΪС�Ƹ���
	char map[12][12]; //���С��λ�ú͹��ӵĵ�ͼ
	int tin; //����
	int movement; //С�ƶ���
	int a, b; //С��ԭ����
	double scoreall[200] ; //����С�Ƶ÷�
	int scoreone[100];//��ֻС����100�ŵ�ͼ�ĳɼ�
	int step = 0; //С�Ʋ���
	int  num_map = 0;//��ͼ������
	int num_gen = 0; //С�Ƶġ�������
	srand(time(0));

	//��ʼ������С�Ƶ÷�
	for (i = 0; i < 200; i++) {
		scoreall[i] = 0;
	}
	//��ʼ����ֻС����100�ŵ�ͼ�ĳɼ�
	for (i = 0; i < 100; i++) {
		scoreone[i] = 0;
	}

	//������ɳ�ʼ�����߱�
	int list_decision[200][243];
	for (int i = 0; i < 200; i++) {
		for (int j = 0; j < 243; j++) {
			list_decision[i][j] = rand() % 7;
		}
	}

	//����С������
	for (i = 0; i < 200; i++) {
		//iΪС�Ƹ���
		for (num_map = 0; num_map < 100; num_map++) {
			//��ʼ���������
			a = 1, b = 1;
			for (n = 0; n < 12; n++) {
				map[0][n] = {'#'};
			}
			for (n = 0; n < 12; n++) {
				map[11][n] = {'#'};
			}
			for (m = 1; m < 11; m++) {
				map[m][0] = {'#'};
			}
			for (m = 1; m < 11; m++) {
				map[m][11] = {'#'};
			}
			for (m = 1; m < 11; m++) {
				for (n = 1; n < 11; n++) {
					tin = rand() % 2;
					switch (tin) {
						case 0:
							map[m][n] = {'@'};
							break;
						case 1:
							map[m][n] = {' '};
							break;
						default:
							;
					}
				}
			}

			for (step = 0; step < 200; step++) {
				//�������ܵ�Ԫ������ж�С�Ƶ�condition��0-243��ֵ
				int condition;
				int left, right, down, up, position; //С����Χ�ĸ���
				switch (map[a - 1][b]) {             //�ж������ӵ�ֵ
					case ' ':
						left = 0;
						break;
					case '@':
						left = 1;
						break;
					case '#':
						left = 2;
						break;
				}
				switch (map[a + 1][b]) {             //�ж��Ҳ���ӵ�ֵ
					case ' ':
						right = 0;
						break;
					case '@':
						right = 1;
						break;
					case '#':
						right = 2;
						break;
				}
				switch (map[a][b + 1]) {           //�ж��²���ӵ�ֵ
					case ' ':
						down = 0;
						break;
					case '@':
						down = 1;
						break;
					case '#':
						down = 2;
						break;
				}
				switch (map[a][b - 1]) {           //�ж��ϲ���ӵ�ֵ
					case ' ':
						up = 0;
						break;
					case '@':
						up = 1;
						break;
					case '#':
						up = 2;
						break;
				}
				switch (map[a][b]) {             //�ж����ڸ��ӵ�ֵ
					case ' ':
						position = 0;
						break;
					case '@':
						position = 1;
						break;
					case '#':
						position = 2;
						break;
				}
				condition = left * 81 + right * 27 + down * 9 + up * 3 + position; //���condition
				int movement = list_decision[i][condition];
loop1:
				switch (movement) {
					case 0: {
						movement = rand() % 7 ;
						goto loop1;
						break;
					}
					case 1: {
						if (a == 1)
							scoreone[num_map] = scoreone[num_map] - 5;
						else
							a = a - 1;
						break;
					}
					case 2: {
						if (a == 10)
							scoreone[num_map] = scoreone[num_map] - 5;
						else
							a = a + 1;
						break;
					}
					case 3: {
						if (b == 1)
							scoreone[num_map] = scoreone[num_map] - 5;
						else
							b = b - 1;
						break;
					}
					case 4: {
						if (b == 10)
							scoreone[num_map] = scoreone[num_map] - 5;
						else
							b = b + 1;
						break;
					}
					case 5: {
						break;
					}
					case 6: {
						if (map[a][b] == '@') {
							scoreone[num_map] = scoreone[num_map] + 10;
							map[a][b] = {' '};
						} else
							scoreone[num_map] = scoreone[num_map] - 2;
						break;
					}
				}
			}
		}
		int total = 0;
		for (int c = 0; c < 100; c++) {
			total = total + scoreone[c];
		}
		scoreall[i] = (double)total / (double)100;

		//��ʼ����ֻС����100�εĳɼ�����ʼ�ܵڶ�ֻС��
		for (j = 0; j < 100; j++) {
			scoreone[j] = 0;
		}
	}

	/*for (i = 0; i < 200; i++) {
		printf("%d %.2f\n", i, scoreall[i]);
	}*/

	//�����С�Ƶľ��ֲ���ӡ
	double score_ave = 0;
	for (int sb = 0; sb < 200; sb++) {
		score_ave = score_ave + scoreall[sb];
	}
	score_ave = (double)score_ave / (double)200;
	printf("Gen_%d_ave:%f\n", num_gen, score_ave);
	//����������Ϊ������
	int rank[200];
	for (i = 0; i < 200; i++) {
		rank[i] = i;
	}

	//����С�Ʒ����ɵ͵����������
	int temp;
	for (i = 0; i < 199; i++) {
		for (j = 199; j > i; j--) {
			if (scoreall[rank[j]] < scoreall[rank[j - 1]]) {
				temp = rank[j];
				rank[j] = rank[j - 1];
				rank[j - 1] = temp;
			}
		}
	}

	/*for (i = 0; i < 200; i++) {
		printf("%d\n", rank[i]);
	}*/

	int rand_num[200];//��ȡС�Ƶ��������
	rand_num [0] = 1;
	for (int i = 1; i < 200; i++) {
		rand_num[i] = rand_num[i - 1] + i ;
	}
	/*for (int i = 0; i < 200; i++) {
		printf("%d\n", rand_num[i]);
	}*/

	//�ڶ���(0-9��)�ľ��߱���ǰ10��ֱ�Ӹ���
	int list_decision_child[200][243];
	int list_decision_parent[200][243];
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 243; j++) {
			list_decision_child[i][j] = list_decision[rank[199 - i]][j];
		}
	}

	//�ڶ�����10-199�ţ��ľ��߱�������õ�190���Ӵ�
	for (int i = 10; i <= 198; i = i + 2) {
		int duck1 = 1 + (rand() % 20100);
		int duck2 = 1 + (rand() % 20100);
		for (int j = 0; j < 200; j++) {
			if (duck1 <= (rand_num[j] + j)) {
				duck1 = j;
				break;
			}
		}
		for (int j = 0; j < 200; j++) {
			if (duck2 <= (rand_num[j] + j)) {
				duck2 = j;
				break;
			}
		}
		//����һ��С�ƾ���
		for (int a = 0; a < 60; a++) {
			list_decision_child[i][a] = list_decision[rank[duck1]][a];
		}
		for (int a = 60; a < 120; a++) {
			list_decision_child[i][a] = list_decision[rank[duck2]][a];
		}
		for (int a = 120; a < 180; a++) {
			list_decision_child[i][a] = list_decision[rank[duck1]][a];
		}
		for (int a = 180; a < 243; a++) {
			list_decision_child[i][a] = list_decision[rank[duck2]][a];
		}
		for (int a = 0; a < 60; a++) {
			list_decision_child[i + 1][a] = list_decision[rank[duck2]][a];
		}
		for (int a = 60; a < 120; a++) {
			list_decision_child[i + 1][a] = list_decision[rank[duck1]][a];
		}
		for (int a = 120; a < 180; a++) {
			list_decision_child[i + 1][a] = list_decision[rank[duck2]][a];
		}
		for (int a = 180; a < 243; a++) {
			list_decision_child[i + 1][a] = list_decision[rank[duck1]][a];
		}
	}
	//����
	for (int m = 10; m < 200; m++) {
		for (int n = 0; n < 243; n++) {
			if ((rand() % mutation_rate) == 0)
				list_decision_child[m][n] = rand() % 7;
		}
	}

	//1����1000��С�ƿ�ʼ����
	for (num_gen = 1; num_gen <= 1000; num_gen++) {
		for (i = 0; i < 200; i++) {
			//iΪС�Ƹ���
			for (num_map = 0; num_map < 100; num_map++) {
				//��ʼ���������
				a = 1, b = 1;
				for (n = 0; n < 12; n++) {
					map[0][n] = {'#'};
				}
				for (n = 0; n < 12; n++) {
					map[11][n] = {'#'};
				}
				for (m = 1; m < 11; m++) {
					map[m][0] = {'#'};
				}
				for (m = 1; m < 11; m++) {
					map[m][11] = {'#'};
				}
				for (m = 1; m < 11; m++) {
					for (n = 1; n < 11; n++) {
						tin = rand() % 2;
						switch (tin) {
							case 0:
								map[m][n] = {'@'};
								break;
							case 1:
								map[m][n] = {' '};
								break;
							default:
								;
						}
					}
				}

				for (step = 0; step < 200; step++) {
					//�������ܵ�Ԫ������ж�С�Ƶ�condition��0-243��ֵ
					int condition;
					int left, right, down, up, position; //С����Χ�ĸ���
					switch (map[a - 1][b]) {             //�ж������ӵ�ֵ
						case ' ':
							left = 0;
							break;
						case '@':
							left = 1;
							break;
						case '#':
							left = 2;
							break;
					}
					switch (map[a + 1][b]) {             //�ж��Ҳ���ӵ�ֵ
						case ' ':
							right = 0;
							break;
						case '@':
							right = 1;
							break;
						case '#':
							right = 2;
							break;
					}
					switch (map[a][b + 1]) {           //�ж��²���ӵ�ֵ
						case ' ':
							down = 0;
							break;
						case '@':
							down = 1;
							break;
						case '#':
							down = 2;
							break;
					}
					switch (map[a][b - 1]) {           //�ж��ϲ���ӵ�ֵ
						case ' ':
							up = 0;
							break;
						case '@':
							up = 1;
							break;
						case '#':
							up = 2;
							break;
					}
					switch (map[a][b]) {             //�ж����ڸ��ӵ�ֵ
						case ' ':
							position = 0;
							break;
						case '@':
							position = 1;
							break;
						case '#':
							position = 2;
							break;
					}
					condition = left * 81 + right * 27 + down * 9 + up * 3 + position; //���condition
					int movement = list_decision_child[i][condition];
loop2:
					switch (movement) {
						case 0: {
							movement = rand() % 7 ;
							goto loop2;
							break;
						}
						case 1: {
							if (a == 1)
								scoreone[num_map] = scoreone[num_map] - 5;
							else
								a = a - 1;
							break;
						}
						case 2: {
							if (a == 10)
								scoreone[num_map] = scoreone[num_map] - 5;
							else
								a = a + 1;
							break;
						}
						case 3: {
							if (b == 1)
								scoreone[num_map] = scoreone[num_map] - 5;
							else
								b = b - 1;
							break;
						}
						case 4: {
							if (b == 10)
								scoreone[num_map] = scoreone[num_map] - 5;
							else
								b = b + 1;
							break;
						}
						case 5: {
							break;
						}
						case 6: {
							if (map[a][b] == '@') {
								scoreone[num_map] = scoreone[num_map] + 10;
								map[a][b] = {' '};
							} else
								scoreone[num_map] = scoreone[num_map] - 2;
							break;
						}
					}
				}
			}
			int total = 0;
			for (int c = 0; c < 100; c++) {
				total = total + scoreone[c];
			}
			scoreall[i] = (double)total / (double)100;

			//��ʼ����ֻС����100�εĳɼ�����ʼ�ܵڶ�ֻС��
			for (j = 0; j < 100; j++) {
				scoreone[j] = 0;
			}
		}
		//�����С�Ƶľ��ֲ���ӡ
		double score_ave = 0;
		for (int sb = 0; sb < 200; sb++) {
			score_ave = score_ave + scoreall[sb];
		}
		score_ave = (double)score_ave / (double)200;
		printf("Gen_%d_ave:%f\n", num_gen, score_ave);
		//С�Ʒ����ɵ͵����������
		for (i = 0; i < 200; i++) {
			rank[i] = i;
		}
		int temp;
		for (i = 0; i < 199; i++) {
			for (j = 199; j > i; j--) {
				if (scoreall[rank[j]] < scoreall[rank[j - 1]]) {
					temp = rank[j];
					rank[j] = rank[j - 1];
					rank[j - 1] = temp;
				}
			}
		}

		//�Ӵ����߱�ת��Ϊ�ױ����߱�
		for (int m = 0; m < 200; m++) {
			for (int n = 0; n < 243; n++) {
				list_decision_parent[m][n] = list_decision_child[m][n];
			}
		}
		//��һ��(0-9��)�ľ��߱���ǰ10��ֱ�Ӹ���
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 243; j++) {
				list_decision_child[i][j] = list_decision_parent[rank[199 - i]][j];
			}
		}
		//��һ����10-199�ţ��ľ��߱�������õ�190���Ӵ�
		for (int i = 10; i <= 198; i = i + 2) {
			int duck1 = 1 + (rand() % 20100);
			int duck2 = 1 + (rand() % 20100);
			for (int j = 0; j < 200; j++) {
				if (duck1 <= (rand_num[j] + j)) {
					duck1 = j;
					break;
				}

			}
			for (int j = 0; j < 200; j++) {
				if (duck2 <= (rand_num[j] + j)) {
					duck2 = j;
					break;
				}
			}
			//�����ױ�С�ƾ���
			for (int a = 0; a < 60; a++) {
				list_decision_child[i][a] = list_decision_parent[rank[duck1]][a];
			}
			for (int a = 60; a < 120; a++) {
				list_decision_child[i][a] = list_decision_parent[rank[duck2]][a];
			}
			for (int a = 120; a < 180; a++) {
				list_decision_child[i][a] = list_decision_parent[rank[duck1]][a];
			}
			for (int a = 180; a < 243; a++) {
				list_decision_child[i][a] = list_decision_parent[rank[duck2]][a];
			}
			for (int a = 0; a < 60; a++) {
				list_decision_child[i + 1][a] = list_decision_parent[rank[duck2]][a];
			}
			for (int a = 60; a < 120; a++) {
				list_decision_child[i + 1][a] = list_decision_parent[rank[duck1]][a];
			}
			for (int a = 120; a < 180; a++) {
				list_decision_child[i + 1][a] = list_decision_parent[rank[duck2]][a];
			}
			for (int a = 180; a < 243; a++) {
				list_decision_child[i + 1][a] = list_decision_parent[rank[duck1]][a];
			}
		}
		//����
		for (int m = 10; m < 200; m++) {
			for (int n = 0; n < 243; n++) {
				if ((rand() % mutation_rate) == 0)
					list_decision_child[m][n] = rand() % 7;
			}
		}
	}
	FILE *fp1;
	fp1 = fopen("Best Strategy.txt", "w");
	for (int i; i < 243; i++) {
		fprintf(fp1, "%d", list_decision_child[199][i]);
	}
	fclose(fp1);
	return 0;
}